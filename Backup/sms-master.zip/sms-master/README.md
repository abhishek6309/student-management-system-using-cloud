# sms
Student Management System With Php

This is the basic project on  Student Mangement System,

i have developed this project when my collage professor hasn't think to start the lecture on php.

# To use this project.

1) Create a database with the name of "sms", and import the sql file into the database server which is in sql directory.
   you can create your database with any name after succesfully create the database, 
   
   Go to include folder and open the dbcon.php file and make change the name of the database name.
   
 - Thanks And Happy Coding,
 
 if you want any helps regarding this or any project,
 
 mail us at socialcodia@gmail.com
 
