<?php
require_once("../include/students/header.php");
require_once("../include/students/sidenav.php");

?>
<nav class="brown darken-4">
    <a href="" class="brand-logo center">Social Codia</a>
</nav>
<div class="mufazmi row">
    <div class="col s12 m12 l12">
        <div class="card z-depth-0">
            <div class="card-title">
                About Social Codia..!
            </div>
            <div class="card-content">
            The SOCIAL CODIA is a synonimous of SOCIAL MEDIA, ok <br>
            The SOCIAL CODIA's mission is to provide infomation all about Programming, Netwoking, Technology and Social Media. <br>
            we have a group of developers and this project is launched by one of our members, <br>

            you know, if you subscirbed, likes or follows our page the you are also a part of our community, <br>
            feel free if you are not a developer , programmer or any other post form infomation technology, then you also don't need to worry, <br>

            we will tech you freely, or if you are developer, programmer or any other post form infomation technology, then that's great news for us and both, <br>

             you have any doubt from any programming language, then please please this is our request we will also help you to solve any query, <br> <br>


            by the way, Let's finish, <br> <br>

            Thanks for following our page , and joining our community.
            </div>
        </div>
    </div>
</div>