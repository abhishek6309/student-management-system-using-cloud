<?php
$dbname = "sms";
$dbusername ="root";
$dbpassword = "";
$dbhost = "localhost";

$con = mysqli_connect($dbhost,$dbusername,$dbpassword,$dbname);
?>